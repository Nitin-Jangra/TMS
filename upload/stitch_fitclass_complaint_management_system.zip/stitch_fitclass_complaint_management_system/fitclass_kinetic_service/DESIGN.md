---
name: FitClass Kinetic Service
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#001d31'
  on-tertiary-container: '#188ace'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system drives the FitClass Complaint & Ticket Management System (FC-CMS), an enterprise-grade mobile SaaS platform built for modern fitness chains, franchise operators, and gym floor managers. The brand aesthetic merges the high-performance energy of premium athletic lifestyle brands with the precision and reliability of modern SaaS infrastructure.

The target audience includes gym general managers, front-desk supervisors, and equipment maintenance teams triaging facility breakdowns, member billing disputes, and trainer conduct issues on the go. The UI evokes:
- **Operational Trust:** Enterprise durability, crisp visual structure, and zero latency ambiguity.
- **Athletic Dynamism:** Kinetic electric-blue accents against cool architectural slate that mirror contemporary training spaces.
- **Clarity Under Pressure:** High-contrast triage surfaces and status badges that allow rapid parsing during floor walkthroughs or crowded peak hours.

The visual style blends **Corporate Modern** with **Refined Tactile Elevation**: clean cool slate planes, micro-radii contours, architectural divider lines, and purposeful status beacons that eliminate operational fatigue.

## Colors

The palette balances authoritative deep navy structural frames with electric athletic blues for primary focal points and enterprise status indicators for triage workflows.

### Primary Role & Accents
- **Primary Navy (`#0F172A` / `#0A192F`):** Anchors core actions, high-priority cards, headers, and dominant interface landmarks. Represents administrative authority and stability.
- **Secondary Kinetic Electric Blue (`#2563EB`):** Applied strictly to active touch targets, key call-to-action buttons, active navigation markers, and focus states.
- **Tertiary Athletic Sky (`#0284C7` / `#38BDF8`):** Serves informational badges, selected states, and real-time metric indicators.

### Surface Tones & Canvases
- **Root Background:** Slate canvas (`#F8FAFC`) creates high contrast against clean white (`#FFFFFF`) card surfaces.
- **Surface Elevation:** Secondary containers use `#F1F5F9` for nested panels, search fields, and table headers.
- **Structural Borders:** Subtle, crisp line work (`#E2E8F0`) establishes clear card boundaries without visual clutter.

### Enterprise SLA Status Badges
Status indicators carry direct operational meaning and follow strict contrast norms:
- **SLA Breach / Urgent (`#EF4444` / Tint `#FEF2F2` / Border `#FCA5A5`):** Overdue maintenance, safety escalations, critical billing blocks.
- **Pending / Action Needed (`#F59E0B` / Tint `#FFFBEB` / Border `#FCD34D`):** Awaiting member response, parts ordered.
- **In-Progress (`#2563EB` / Tint `#EFF6FF` / Border `#BFDBFE`):** Assigned technician or staff actively addressing the ticket.
- **Resolved / Operational (`#10B981` / Tint `#ECFDF5` / Border `#A7F3D0`):** Repaired, resolved dispute, completed check-in audit.

## Typography

The design system uses **Plus Jakarta Sans** across all typographic levels. Its geometric proportions bring a contemporary athletic feel, while its open counters and tall x-height maintain high legibility when staff view ticketing logs on mobile devices under gym floor lighting.

- **Headlines (`headline-xl`, `headline-lg`):** Feature tight tracking (`-0.02em` to `-0.025em`) and heavy weights (700/800) to command attention for ticket titles, dashboard stats, and facility IDs. Mobile-specific overrides ensure titles never wrap uncontrollably.
- **Section Titles (`headline-md`, `title-sm`):** Deliver sharp grouping headers over lists, ticket detail groups, and SLA chronologies.
- **Body Hierarchy (`body-lg`, `body-md`, `body-sm`):** Set at regular weight with generous line-height ratios (1.4-1.5) for long member complaint logs, audit remarks, and technician diagnostic notes.
- **Badges & Meta Labels (`label-md`, `label-sm`):** Set in semibold and bold with deliberate letter spacing (`0.02em` to `0.04em`). Frequently used with uppercase transforms for SLA tags, ticket priority levels, and timestamp metadata.

## Layout & Spacing

The layout model is optimized for mobile touch ergonomics with fluid responsiveness across tablet and desktop operational dashboards.

### Fluid 4-to-12 Column Grid
- **Mobile (<640px):** 4-column fluid layout with a `1rem` outer canvas margin (`margin-mobile`) and `0.75rem` gutters (`gutter-mobile`). Full single-column stacked tickets maximize horizontal readability for member complaint text.
- **Tablet (640px - 1024px):** 8-column layout with `1.5rem` margins and `1rem` gutters. Accommodates split views (master ticket feed on left, triage drawer on right).
- **Desktop / Front Desk Console (>1024px):** 12-column layout centered with max width capped at `1440px`.

### Spacing Rhythm
Component internal padding strictly respects the 4px baseline rhythm (`space-xs: 4px`, `space-sm: 8px`, `space-md: 16px`, `space-lg: 24px`, `space-xl: 32px`). Card interiors use `space-md` for compact mobile efficiency, while section separations use `space-lg`. Interactive targets preserve a minimum 44x44px touch envelope.

## Elevation & Depth

Visual hierarchy uses crisp boundary surfaces paired with soft micro-shadows, prioritizing high clarity over heavy, distracting elevation layers.

### Tonal Hierarchy & Surfaces
- **Level 0 (Canvas):** Base background `#F8FAFC`. Unhovered, non-interactive backdrop.
- **Level 1 (Card & Module Surface):** Surface `#FFFFFF` enclosed by a 1px solid border (`#E2E8F0`) and supported by a subtle micro-shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.05), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`.
- **Level 2 (Active/Selected Card & Popovers):** `#FFFFFF` paired with an electric blue-tinted elevation shadow: `0 4px 6px -1px rgba(37, 99, 235, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Sticky Bottom Sheets & Modals):** High-priority overlays use `0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.06)`, anchored over a darkened navy backdrop (`rgba(10, 25, 47, 0.4)`).

Borders remain functional: interactive components utilize `#CBD5E1` in hovered states and `#2563EB` when focused.

## Shapes

The design system adopts a balanced rounded corner geometry (Level 2) that softens dense SaaS operational screens while maintaining a disciplined architectural profile.

- **Base Radius (0.5rem / 8px):** Applied to form inputs, search fields, compact enterprise badges, buttons, and segmented filters.
- **Large Radius (`rounded-lg`, 1rem / 16px):** Primary container curvature for complaint ticket cards, member profile preview cards, and SLA breakdown metrics.
- **Extra Large Radius (`rounded-xl`, 1.5rem / 24px):** Mobile bottom action sheets, slide-over triage drawers, and modal dialogs.
- **Circular (`rounded-full`):** Reserved for member avatars, status pip beacons, floating quick-action buttons (+ ticket), and counter pills.

## Components

### Buttons
- **Primary Athletic:** Background `#2563EB`, text `#FFFFFF`, rounded 8px (`rounded-md`), vertical padding 12px, horizontal padding 20px. Hover transitions to `#1D4ED8`; active scale down to 0.98.
- **Secondary Corporate:** Background `#0F172A`, text `#FFFFFF`, rounded 8px. Applied for ticket closures, administrative approvals, and export actions.
- **Outline / Ghost:** Border 1px solid `#E2E8F0`, background `#FFFFFF`, text `#0F172A`. On hover, background shifts to `#F8FAFC`.
- **Destructive:** Background `#EF4444`, text `#FFFFFF`, for permanent escalation or contract termination.

### SLA & Status Badges
Badges are compact indicators with a height of 24px, 8px horizontal padding, and a border radius of 6px.
- **Breach Alert:** `#FEF2F2` background, `#EF4444` label, `#FCA5A5` 1px border, paired with an illuminated pulse dot.
- **In-Progress:** `#EFF6FF` background, `#2563EB` label, `#BFDBFE` 1px border.
- **Pending Member/Vendor:** `#FFFBEB` background, `#D97706` label, `#FCD34D` 1px border.
- **Resolved:** `#ECFDF5` background, `#059669` label, `#A7F3D0` 1px border.

### Ticket Cards
- Base: White background, 16px corner radius (`rounded-lg`), 1px solid `#E2E8F0`, interior padding `space-md` (16px).
- Structure:
  1. Top metadata row: Ticket Key (e.g., `#FC-8492` in bold `#64748B`), Gym Location / Club Zone pill, SLA timer pill.
  2. Core content: Complaint title in `title-sm` (`#0F172A`), followed by 2-line truncated description in `body-sm` (`#475569`).
  3. Footer: Assignee avatar circle, member category tag (e.g., "VIP Member", "Cardio Deck B"), and status badge right-aligned.

### Input Fields & Selectors
- Height 44px, background `#FFFFFF`, border 1px solid `#CBD5E1`, border-radius 8px.
- Placeholder text in `#94A3B8`.
- Focus state: Border color changes to `#2563EB` with an external glow ring `0 0 0 3px rgba(37, 99, 235, 0.15)`.
- Error state: Border color `#EF4444` with helper text in `label-md` red.

### Checkboxes & Radio Controls
- 20x20px dimension, 4px border radius on checkboxes, full circle on radio buttons.
- Default: Border 1.5px solid `#94A3B8`, background `#FFFFFF`.
- Checked: Background `#2563EB`, border `#2563EB` with white check or center pip.

### Lists & Activity Logs
- Dividers use 1px solid `#F1F5F9`.
- Timeline nodes feature a 2px vertical connector line in `#E2E8F0` with colored activity status dots (`#2563EB` for comments, `#10B981` for resolutions, `#F59E0B` for reassignment).

### Additional Product Components
- **SLA Breach Countdown Clock:** Compact pill timer displaying remaining resolution minutes in high-contrast red/slate with a persistent countdown animation.
- **Gym Asset Tag:** Micro badge linking the complaint directly to specific equipment (e.g., "Treadmill #12 - Matrix T70").
- **Quick-Triage Bottom Sheet:** One-thumb mobile panel sliding up from screen base to reassign staff, escalate priority, or close tickets with predefined resolution templates.